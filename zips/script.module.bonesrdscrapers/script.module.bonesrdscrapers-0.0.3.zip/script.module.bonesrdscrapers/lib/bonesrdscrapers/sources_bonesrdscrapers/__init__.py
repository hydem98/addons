# -*- coding: UTF-8 -*-

import os.path


from . import en_DebridOnly
from . import en_Torrent



scraper_source = os.path.dirname(__file__)
__all__ = [x[1] for x in os.walk(os.path.dirname(__file__))][0]



##--en_DebridOnly--##
debrid_source = en_DebridOnly.sourcePath
debrid_providers = en_DebridOnly.__all__

##--en_Torrent--##
torrent_source = en_Torrent.sourcePath
torrent_providers = en_Torrent.__all__

##--Paid Debrid(Debrid and Torrents)--##
paid_providers = {'en_DebridOnly': debrid_providers, 'en_Torrent': torrent_providers}
all_paid_providers = []
try:
	for key, value in paid_providers.iteritems():
		all_paid_providers += value
except:
	for key, value in paid_providers.items():
		all_paid_providers += value



##--All Providers--##
total_providers = {'en_Debrid': debrid_providers, 'en_Torrent': torrent_providers}
all_providers = []
try:
	for key, value in total_providers.iteritems():
		all_providers += value
except:
	for key, value in total_providers.items():
		all_providers += value
