# -*- coding: utf-8 -*-

import sys
try:
	from urlparse import parse_qsl
except:
	from urllib.parse import parse_qsl

from bonesrdscrapers import sources_bonesrdscrapers
from bonesrdscrapers.modules import control

params = dict(parse_qsl(sys.argv[2].replace('?', '')))
action = params.get('action')
mode = params.get('mode')
query = params.get('query')


if action == "bonesrdscrapersSettings":
	control.openSettings('0.0', 'script.module.bonesrdscrapers')


elif mode == "bonesrdscrapersSettings":
	control.openSettings('0.0', 'script.module.bonesrdscrapers')


elif action == "Defaults":
	sourceList = []
	sourceList = sources_bonesrdscrapers.all_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		value = control.getSettingDefault(source_setting)
		control.setSetting(source_setting, value)
	# xbmc.log('provider-default = %s-%s' % (source_setting, value), 2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == "toggleAll":
	sourceList = []
	sourceList = sources_bonesrdscrapers.all_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == "toggleAllPaid":
	sourceList = []
	sourceList = sources_bonesrdscrapers.all_paid_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Paid providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == 'ShowChangelog':
	from bonesrdscrapers.modules import changelog
	changelog.get()
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == "toggleAllHosters":
	sourceList = []
	sourceList = sources_bonesrdscrapers.hoster_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Hoster providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == "toggleAllForeign":
	sourceList = []
	sourceList = sources_bonesrdscrapers.all_foreign_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Foregin providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == "toggleAllGerman":
	sourceList = []
	sourceList = sources_bonesrdscrapers.german_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All German providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == "toggleAllSpanish":
	sourceList = []
	sourceList = sources_bonesrdscrapers.spanish_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Spanish providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == "toggleAllFrench":
	sourceList = []
	sourceList = sources_bonesrdscrapers.french_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Spanish providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == "toggleAllGreek":
	sourceList = []
	sourceList = sources_bonesrdscrapers.greek_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Greek providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == "toggleAllKorean":
	sourceList = []
	sourceList = sources_bonesrdscrapers.korean_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Spanish providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == "toggleAllPolish":
	sourceList = []
	sourceList = sources_bonesrdscrapers.polish_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Polish providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == "toggleAllRussian":
	sourceList = []
	sourceList = sources_bonesrdscrapers.russian_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Polish providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == "toggleAllDebrid":
	sourceList = []
	sourceList = sources_bonesrdscrapers.debrid_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Debrid providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")


elif action == "toggleAllTorrent":
	sourceList = []
	sourceList = sources_bonesrdscrapers.torrent_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Torrent providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonesrdscrapers")