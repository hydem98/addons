# -*- coding: utf-8 -*-

import sys
try:
	from urlparse import parse_qsl
except:
	from urllib.parse import parse_qsl

from bonescrapers import sources_bonescrapers
from bonescrapers.modules import control

params = dict(parse_qsl(sys.argv[2].replace('?', '')))
action = params.get('action')
mode = params.get('mode')
query = params.get('query')


if action == "bonescrapersSettings":
	control.openSettings('0.0', 'script.module.bonescrapers')


elif mode == "bonescrapersSettings":
	control.openSettings('0.0', 'script.module.bonescrapers')


elif action == "Defaults":
	sourceList = []
	sourceList = sources_bonescrapers.all_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		value = control.getSettingDefault(source_setting)
		control.setSetting(source_setting, value)
	# xbmc.log('provider-default = %s-%s' % (source_setting, value), 2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == "toggleAll":
	sourceList = []
	sourceList = sources_bonescrapers.all_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == "toggleAllPaid":
	sourceList = []
	sourceList = sources_bonescrapers.all_paid_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Paid providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == 'ShowChangelog':
	from bonescrapers.modules import changelog
	changelog.get()
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == "toggleAllHosters":
	sourceList = []
	sourceList = sources_bonescrapers.hoster_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Hoster providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == "toggleAllForeign":
	sourceList = []
	sourceList = sources_bonescrapers.all_foreign_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Foregin providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == "toggleAllGerman":
	sourceList = []
	sourceList = sources_bonescrapers.german_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All German providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == "toggleAllSpanish":
	sourceList = []
	sourceList = sources_bonescrapers.spanish_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Spanish providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == "toggleAllFrench":
	sourceList = []
	sourceList = sources_bonescrapers.french_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Spanish providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == "toggleAllGreek":
	sourceList = []
	sourceList = sources_bonescrapers.greek_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Greek providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == "toggleAllKorean":
	sourceList = []
	sourceList = sources_bonescrapers.korean_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Spanish providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == "toggleAllPolish":
	sourceList = []
	sourceList = sources_bonescrapers.polish_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Polish providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == "toggleAllRussian":
	sourceList = []
	sourceList = sources_bonescrapers.russian_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Polish providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == "toggleAllDebrid":
	sourceList = []
	sourceList = sources_bonescrapers.debrid_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Debrid providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")


elif action == "toggleAllTorrent":
	sourceList = []
	sourceList = sources_bonescrapers.torrent_providers
	for i in sourceList:
		source_setting = 'provider.' + i
		control.setSetting(source_setting, params['setting'])
	# xbmc.log('All Torrent providers = %s' % sourceList,2)
	control.sleep(200)
	control.openSettings(query, "script.module.bonescrapers")