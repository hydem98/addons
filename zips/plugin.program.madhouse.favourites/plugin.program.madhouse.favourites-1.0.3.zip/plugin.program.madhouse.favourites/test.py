import xbmc
            cmd = 'runscript(special://home/addons/plugin.program.madhouse.favourites/capture.py)'